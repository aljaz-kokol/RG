#include "Model.h"
#include "../../renderer/Renderer.h"
#include "../../utils/RotationDirection.h"

Model::Model(const ShaderProgram &program): program(program), positions(0), rotation(0), translation(glm::vec3(0)), scale(1), color(Color::WHITE) {
    transformations = {
        std::make_shared<Translation>(translation),
        std::make_shared<Rotation>(rotation),
        std::make_shared<Scale>(scale),
    };
}

Model::Model(const ShaderProgram &program, const Camera& camera)
: program(program),rotation(0), scale(1), color(Color::WHITE), translation(camera.getPosition()), positions(0)
{
    const glm::mat3& rotationMatrix = glm::mat3(camera.getViewMatrix());
    float yawAngle = atan2(rotationMatrix[0][2], rotationMatrix[2][2]);
    float pitchAngle = asin(-rotationMatrix[1][2]);

    rotation.setYAngle(glm::degrees(yawAngle));
    rotation.setXAngle(glm::degrees(pitchAngle));

    transformations = {
        std::make_shared<Translation>(translation),
        std::make_shared<Rotation>(rotation),
        std::make_shared<Translation>(glm::vec3(0, 0, -5)),
    };

    glm::mat4 modelMatrix(1);
    for (const auto& transformation : transformations) {
        modelMatrix *= transformation->transform();
    }

    positions = glm::vec3(modelMatrix[3][0], modelMatrix[3][1], modelMatrix[3][2]);
    translation.setValues(positions);
}

void Model::load(std::string_view fileName) {
    Assimp::Importer importer;
    const aiScene* scene = importer.ReadFile(fileName.data(), aiProcess_Triangulate | aiProcess_FlipUVs | aiProcess_GenSmoothNormals | aiProcess_JoinIdenticalVertices);
    if (!scene) {
        throw std::invalid_argument("Model " + std::string(fileName) + " failed to load : " + importer.GetErrorString());
    }
    loadNodes(scene->mRootNode, scene);
    loadMaterials(scene);
}

void Model::loadNodes(aiNode *node, const aiScene *scene) {
    for (size_t i = 0; i < node->mNumMeshes; i++) {
        loadMesh(scene->mMeshes[node->mMeshes[i]], scene);
    }
    for (size_t i = 0; i < node->mNumChildren; i++) {
        loadNodes(node->mChildren[i], scene);
    }
}

void Model::loadMaterials(const aiScene *scene) {
    textureList.resize(scene->mNumMaterials);
    for (size_t i = 0; i < scene->mNumMaterials; i++) {
        aiMaterial* material = scene->mMaterials[i];
        textureList[i] = nullptr;
        if (material->GetTextureCount(aiTextureType_DIFFUSE)) {
            aiString path;
            if (material->GetTexture(aiTextureType_DIFFUSE, 0, &path) == AI_SUCCESS) {
                int32_t index = std::string(path.data).rfind('\\');
                std::string fileName = std::string(path.data).substr(index + 1);
                std::string texPath = "assets/textures/" + fileName;
                textureList[i] = std::make_shared<Texture>(texPath);
                try {
                    textureList[i]->loadRGB();
                } catch (const std::exception& ex) {
                    textureList[i] = nullptr;
                }
            }
        }
        if (!textureList[i]) {
            textureList[i] = std::make_shared<Texture>("assets/textures/plain.png");
            textureList[i]->loadRGBA();
        }
    }
}

void Model::loadMesh(aiMesh *mesh, const aiScene *scene) {
    std::vector<GLfloat> vertices;
    std::vector<uint32_t> indices;
    for (size_t i = 0; i < mesh->mNumVertices; i++) {
        vertices.insert(vertices.end(), { mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z });
        if (mesh->mTextureCoords[0]) { // load first texture
            vertices.insert(vertices.end(), { mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y });
        } else {
            vertices.insert(vertices.end(), { 0.0f, 0.0f });
        }
        vertices.insert(vertices.end(), { -mesh->mNormals[i].x, -mesh->mNormals[i].y, -mesh->mNormals[i].z  });
    }

    for (size_t i = 0; i < mesh->mNumFaces; i++) {
        aiFace face = mesh->mFaces[i];
        for (size_t j = 0; j < face.mNumIndices; j++) {
            indices.push_back(face.mIndices[j]);
        }
    }

    std::shared_ptr<TextureMesh> newMesh = std::make_shared<TextureMesh>(program, vertices, indices);
    dimensions.width += newMesh->getDimensions().width;
    dimensions.height += newMesh->getDimensions().height;
    dimensions.depth += newMesh->getDimensions().depth;
    meshList.push_back(newMesh);
    meshToTex.push_back(mesh->mMaterialIndex);
}

void Model::move(const Direction& direction, float value, GLfloat delta) {
    const GLfloat VELOCITY = value * delta;
    if (direction == Direction::LEFT) {
        positions[0] -= value * VELOCITY;
    } else if (direction == Direction::RIGHT) {
        positions[0] += value * VELOCITY;
    } else if (direction == Direction::UP) {
        positions[1] += value * VELOCITY;
    } else if (direction == Direction::DOWN) {
        positions[1] -= value * VELOCITY;
    } else if (direction == Direction::FRONT) {
        positions[2] += value * VELOCITY;
    } else if (direction == Direction::BACK) {
        positions[2] -= value * VELOCITY;
    }

    translation.setValues(positions);

    transformations = {
        std::make_shared<Translation>(translation),
        std::make_shared<Rotation>(rotation),
        std::make_shared<Scale>(scale),
    };
}

void Model::rotate(const RotationDirection& direction, float value, GLfloat delta) {
    const GLfloat VELOCITY = value * delta;
    int8_t rotationDirValue = static_cast<std::underlying_type<RotationDirection>::type>(direction) < 0 ? -1 : 1;
    if (direction == RotationDirection::X_POS || direction == RotationDirection::X_NEG) {
        rotation.setXAngle(rotation.getAngles().x + rotationDirValue * value*  VELOCITY);
    } else if (direction == RotationDirection::Y_POS || direction == RotationDirection::Y_NEG) {
        rotation.setYAngle(rotation.getAngles().y + rotationDirValue * value* VELOCITY);
    } else if (direction == RotationDirection::Z_POS || direction == RotationDirection::Z_NEG) {
        rotation.setZAngle(rotation.getAngles().z + rotationDirValue * value* VELOCITY);
    }
    transformations = {
            std::make_shared<Translation>(translation),
            std::make_shared<Rotation>(rotation),
            std::make_shared<Scale>(scale),
    };
}

void Model::draw() const {
    for (size_t i = 0; i < meshList.size(); i++) {
        uint32_t materialIndex = meshToTex[i];
        if (materialIndex < textureList.size() && textureList[materialIndex]) {
            textureList[materialIndex]->bind();
        }
        meshList[i]->setColor(color);
        meshList[i]->applyTransformations("model", transformations);
        Renderer::draw<DrawMode::TRIANGLES>(*meshList[i]);
    }
}

void Model::draw(const Camera &camera) const {
    for (size_t i = 0; i < meshList.size(); i++) {
        meshList[i]->setColor(color);

        glm::mat3 rotationMatrix = glm::mat3(camera.getViewMatrix());
        float yawAngle = atan2(rotationMatrix[0][2], rotationMatrix[2][2]);
        float pitchAngle = asin(-rotationMatrix[1][2]); // Invert the sign due to OpenGL coordinate system

        meshList[i]->applyTransformations("model", {
            std::make_shared<Translation>(camera.getPosition()),
            std::make_shared<Rotation>(glm::degrees(yawAngle), glm::vec3(0.0, 1.0, 0.0)),
            std::make_shared<Rotation>(glm::degrees(pitchAngle), glm::vec3(1.0, 0.0, 0.0)),

            std::make_shared<Translation>(translation),
            std::make_shared<Rotation>(rotation),
            std::make_shared<Scale>(scale),
        });
        Renderer::draw<DrawMode::TRIANGLES>(*meshList[i]);
    }
}

void Model::applyTransformAndDraw(const Transformations &transformations) const {
    for (size_t i = 0; i < meshList.size(); i++) {
        meshList[i]->setColor(color);
        meshList[i]->applyTransformations("model", transformations);
        Renderer::draw<DrawMode::TRIANGLES>(*meshList[i]);
    }
}

const Dimensions &Model::getDimensions() const {
    return dimensions;
}

const glm::vec3 &Model::getPositions() const {
    return positions;
}

void Model::setColor(const Color &color) {
    this->color = color;
}