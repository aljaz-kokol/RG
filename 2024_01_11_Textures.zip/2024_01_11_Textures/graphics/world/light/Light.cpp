#include "Light.h"

Light::Light(const ShaderProgram& program): program(program) {}
